window.addEventListener('load', function () {
  Vue.config.devtools = true

  new Vue({
    el: '#synk',
    data: {
      tickets: {},
      config: {
        username: "",
        password: "",
        field: "Story points"
      }
    },
    methods: {
      issueLinkToApiUrl(issueLink) {
        // http://localhost:8080/browse/POK-4 => http://localhost:8080/rest/api/2/issue/POK-1
        const anchorTag = document.createElement('a')
        anchorTag.href = issueLink
        const matches = /\/browse\/(.*)/.exec(anchorTag.pathname)
        return matches && `${anchorTag.origin}/rest/api/2/issue/${matches[1]}`
      },
      jiraHostFromUrl(url) {
        const anchorTag = document.createElement("a")
        anchorTag.href = url
        return anchorTag.origin
      },
      isValidUrl(url) {
        const regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/
        return !!regex.test(url)
      },
      setSyncStatus(link, statusText) {
        let linkItem = {}
        linkItem[link] = { ...this.tickets[link], status: statusText }
        this.tickets = {...this.tickets, ...linkItem }
      },
      handleSynk() {
        const auth = {
          username: this.config.username,
          password: this.config.password
        }
        chrome.storage.sync.set({auth: auth}, () => {
          console.log("Auth info saved")
        })

        for(let [link, story] of Object.entries(this.tickets)) {
          if(this.isValidUrl(link)) {
            const ticketPoint = isNaN(story.point) ? story.point : parseFloat(story.point)
            this.setSyncStatus(link, "In progress")
            axios.request({
              url: `${this.jiraHostFromUrl(link)}/rest/api/2/field`,
              method: "get",
              headers: { 'content-type': 'application/json' },
              responseType: 'json',
              auth: auth
            }).then((response) => {
              let pointField = response.data
                .find(jiraField => jiraField.name.toLowerCase() === this.config.field.toLowerCase())
                .id
              console.log("===Update Issue")
              fieldsToUpdate = {}
              fieldsToUpdate[pointField] = ticketPoint
              axios.request({
                url: this.issueLinkToApiUrl(link),
                method: "put",
                headers: { 'content-type': 'application/json'  },
                responseType: 'json',
                auth: auth,
                data: {
                  fields: fieldsToUpdate
                }
              }).then((response) => {
                console.log(`Updated: ${link}`)
                this.setSyncStatus(link, "✅")
              }).catch((error) => {
                console.log(error)
              })
            }).catch((error) => {
              console.log(error)
            })
          } else {
            this.setSyncStatus(link, "skipped")
          }
        }
      }
    },
    mounted () {
      chrome.storage.sync.get("auth", (result) => {
        const auth = result["auth"] || {}
        this.config = { ...this.config, username: auth.username, password: auth.password }
      })
      const roomId= location.hash.slice(1)
      if(roomId.length) {
        axios.request({
          baseURL: `${POKREX_HOST}/api/v1`,
          url: `/rooms/${roomId}`,
          timeout: 1000
        }).then((response) => {
          this.tickets = response["data"]["data"]
        }).catch((error) => {
          console.error(error)
        })
      }
    }
  })
})
