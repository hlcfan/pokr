window.addEventListener('load', function () {
  new Vue({
    el: '#rooms-table',
    data: {
      rooms: []
    },
    methods: {
    },
    mounted () {
      axios.request({
        baseURL: `${POKREX_HOST}/api/v1`,
        url: "/rooms.json",
        timeout: 1000
      }).then((response) => {
        this.rooms = response["data"]["data"]
      }).catch((error) => {
        console.error(error)
      })
    }
  })
})
