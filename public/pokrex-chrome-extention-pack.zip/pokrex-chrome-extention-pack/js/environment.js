const POKREX_HOST = "https://pokrex.com"
