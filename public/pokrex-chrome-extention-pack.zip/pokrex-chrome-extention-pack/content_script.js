// Show add button on issue list page
let jiraPage = document.getElementById("jira")
if (typeof(jiraPage) !== 'undefined' && jiraPage !== null) {
  setTimeout(() => {
    // console.log("===Start loading content script===")
    // var issueItems = document.querySelectorAll(".js-issue")
    // for (var i = 0; i < issueItems.length; i++) {
    //   let button = document.createElement("button")
    //   button.className = "pokrex-add-btn-board"
    //   let text = document.createTextNode("Add")
    //   button.appendChild(text)
    //   button.addEventListener("click", function(e) {
    //     e.preventDefault()
    //     e.stopPropagation()
    //     let issueId = e.target.parentNode.getAttribute("data-issue-key")
    //     let issueLink = `${location.origin}/browse/${issueId}`
    //     chrome.storage.sync.get("prepItems", (result) => {
    //       let prepItems = result["prepItems"] || []
    //       prepItems.push({link: issueLink})
    //       chrome.storage.sync.set({prepItems: prepItems}, () => {
    //         console.dir(prepItems)
    //       });
    //     })
    //   })
    //   issueItems[i].appendChild(button)
    // }

    let issueSearchItems = document.querySelectorAll(".issuerow .issuekey")

    let tooltipBar = document.querySelector(".aui-toolbar2-primary, .toolbar-split-left")
    if (typeof(tooltipBar) !== 'undefined' && tooltipBar !== null) {
      let buttonOnIssuePage = document.createElement("button")
      buttonOnIssuePage.textContent = "Add to Pokrex"
      buttonOnIssuePage.className = "pokrex-add-to-btn-issue-page"
      buttonOnIssuePage.addEventListener("click", function(e) {
        e.preventDefault()
        e.stopPropagation()
        let issueId = document.querySelector("#key-val,.issue-link").getAttribute("data-issue-key")
        let issueLink = location.origin + location.pathname
        chrome.storage.sync.get("prepItems", (result) => {
          let prepItems = result["prepItems"] || []
          if(!prepItems.find(item => item.link == issueLink)) {
            prepItems.push({link: issueLink})
          }
          chrome.storage.sync.set({prepItems: prepItems}, () => {
            console.dir(prepItems)
          });
        })
      })
      tooltipBar.appendChild(buttonOnIssuePage)
    }
  }, 1000)
}

// Listen to "Sync" on click event from room page
const synkLink = document.querySelectorAll("#synk-link, #synk-button")
for(var i = 0; i<synkLink.length; i++) {
  synkLink[i].addEventListener("click", (e) => {
    chrome.runtime.sendMessage({message: "synkLinkClicked", roomId: location.pathname.slice(7)}, () => {
    })
  })
}

// Fill DIV with extension id
const extensionCheckElement = document.getElementById("browser-extension-check")
if (typeof(extensionCheckElement) !== 'undefined' && extensionCheckElement !== null) {
  extensionCheckElement.innerText = chrome.runtime.id
}
