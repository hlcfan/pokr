window.addEventListener('load', function () {
  Vue.config.devtools = true

  new Vue({
    el: '#prep-table',
    data: {
      groom_items: [],
      name:        "",
      timer:       "",
      mode:        "",
      // todo: save to preference
      scheme:      "fibonacci",
      schemes:     [],
      moderators:  []
    },
    methods: {
      removeFromPrep: function(link) {
        this.groom_items = this.groom_items.filter((item, index, arr) => {
          return item.link !== link
        })
        chrome.storage.sync.set({prepItems: this.groom_items}, () => {
          console.dir(this.groom_items)
        })
      },
      createRoom: function() {
        let groomItemsIndex = 0
        let groomItemsAttributes = {}
        this.groom_items.forEach((item) => {
          groomItemsIndex += 1
          groomItemsAttributes[groomItemsIndex] = item
        })
        var request = new XMLHttpRequest()
        request.open("POST", `${POKREX_HOST}/rooms.json`, true)
        request.setRequestHeader("Content-Type", "application/json;charset=UTF-8")
        request.onreadystatechange = function() {
          if (request.readyState === 4) {
            let response = JSON.parse(request.response)
            location.href = response.url
          }
        }
        request.send(JSON.stringify({
          room: {
            name: this.name,
            stories_attributes: groomItemsAttributes,
            moderator_ids: this.moderators.join(","),
            timer: this.timer,
            style: this.mode,
            scheme: this.scheme
          }
        }))
      }
    },
    mounted() {
      axios.request({
        url: `${POKREX_HOST}/api/v1/schemes.json`,
        method: "get",
        headers: { 'content-type': 'application/json' },
        responseType: 'json',
      }).then((response) => {
        this.schemes = response["data"]["data"]
      })

      let input = document.querySelector('#room-moderators')
      let controller
      let tagify = new Tagify(input, {
        whitelist : [],
        enforceWhitelist: true,
        dropdown : {
          classname : "color-blue",
          enabled   : 3,
          maxItems  : 5
        },
        callbacks: {
          add: (e) => {
            this.moderators.push( e.detail.id )
          }
        }
      })
      tagify.on("input", (e) => {
        let value = e.detail.value
        tagify.settings.whitelist.length = 0; // reset the whitelist

        // https://developer.mozilla.org/en-US/docs/Web/API/AbortController/abort
        controller && controller.abort();
        controller = new AbortController(); 

        fetch(`${POKREX_HOST}/users/autocomplete.json?term=` + value, {signal:controller.signal})
          .then(RES => RES.json())
          .then((whitelist) => {
            tagify.settings.whitelist = whitelist;
            tagify.dropdown.show.call(tagify, value); // render the suggestions dropdown
          })
      })
    },
    beforeCreate () {
      chrome.storage.sync.get("prepItems", (data) => {
        console.log(data["prepItems"])
        this.groom_items = data["prepItems"]
      })
    }
  })
})
